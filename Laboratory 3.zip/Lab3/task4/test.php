<?php
include 'animal.php';
include 'dog.php';
$dog = new dog("dog","grey");
$dog->facts();
?>