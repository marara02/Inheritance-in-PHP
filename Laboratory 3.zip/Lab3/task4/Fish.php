<!DOCTYPE html>
<html>
<head>
    <title>The Parrot</title>
    <style>
        body{
            background-image: linear-gradient(to right, #89f7fe , #66a6ff);
            background-size: cover;
        }
        .parrot{
            background-color:aquamarine;
            width:50%;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body>
<form method = 'post'>
    <select name = 'fishes[]' >
        <option value = 'Alpha'>Alpha</option>
        <option value = 'Franky'>Franky</option>
        <option value = 'Rainbowfish'>Rainbowfish</option>
        <option value = 'Blue corydoras'>Blue corydoras</option>
        <option value = 'Evelyn cory'>Evelyn's cory</option>
    </select>
    <input type = 'submit' name = 'submit' value = Submit>
</form>
</body>
</html>
<?php
include 'animal.php';
class Fish extends animal
{

    public function Choose()
    {
        if(isset($_POST['submit'])){
            if(isset($_POST['fishes'])){
                foreach($_POST['fishes'] as $types)
                    print $types;}
            }
        }
                public function Factsss(){
                    $fff = "                  
                    <div class = fish>
                    What percentage of a fish's size is made up of brain? Fish typically have quite small brains relative to body size compared with other vertebrates,
                    typically one-fifteenth (0.06 per cent) the brain mass of a similarly sized bird or mammal.
                    <br>
                    Did you know, fish can get sunburn, but it is unusual unless there is something about their environment that does not allow them to seek deeper
                    water or some kind of shelter.
                    <br>
                    It was not until 1853 in London, UK, when aeration and filtration of water was understood, that people were able to keep fish as indoor pets.
</div>";
                    print $fff;
            }
}
$Fish = new Fish("Fish","Colourful");
$Fish->Choose();
$Fish->Factsss();