<!DOCTYPE html>
<html>
<head>
    <title>The Rabbit</title>
    <style>
        body{
            background-image: linear-gradient(to right, #89f7fe , #66a6ff);
            background-size: cover;
        }
        .rabbit{
            background-color:darkturquoise;
            width:50%;
            margin-left: auto;
            margin-right: auto;
        }
        p{
            font-size: 25px;
        }
    </style>
</head>
<body>
<div style="text-align: center;">
<form method = 'post'>
    <select name = 'types[]' >
        <option value = 'Domestic'>Domestic</option>
        <option value = 'Decorative'>Decorative</option>
        <option value = 'Wild'>Wild</option>
    </select>
    <input type = 'submit' name = 'submit' value = Submit>
</form></div>
</body>
<?php
include 'animal.php';
class Rabbit extends animal{
    public function Check(){
        if(isset($_POST['submit'])){
            if(isset($_POST['types'])){
                foreach($_POST['types'] as $types)
                    if($types == 'Domestic'){
                        print 'Correct domestic type';
                    }
                    if($types == 'Decorative'){
                        print 'Rabbit can grow faster than domestic one';
                    }
                }
                }
            }
            public function FactR(){
        $facts = <<<Here
<div class = "rabbit"><p>If you spend enough time around rabbits, you may be lucky enough to witness one of the cutest behaviors in nature. 
                        A bunny will hop when it's happy and do a twist in mid-air. This adorable action has an equally adorable name: It's called a binky.
                        <br>
                        One rabbit behavior that is significantly less adorable: After digesting a meal, rabbits will sometimes eat their own
                        poop and process it a second time. It may seem gross, but droppings are actually an essential part of a rabbit's diet.
                        They even produce a special type of poop called cecotropes that are softer than their normal pellets and meant to be eaten. 
                        Rabbits have a fast-moving digestive system, and by redigesting waste, they're able to absorb nutrients their bodies missed the first time around.
                        </p></div>
Here;
        print $facts;
            }
}
$Rabbit = new Rabbit("Rabbit","Grey and White");
$Rabbit->Check();
$Rabbit->FactR();
