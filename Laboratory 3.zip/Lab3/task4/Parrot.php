<html>
<head>
    <title>The Parrot</title>
    <style>
        body{
            background-image: linear-gradient(to right, #89f7fe , #66a6ff);
            background-size: cover;
        }
        .parrot{
            background-color:darkturquoise;
            width:50%;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
</html>
<?php
include 'animal.php';
class Parrot extends animal{
    public function FactsParr(){
    print '
           <div class = "parrot">
           <h3>Habits <br>
           Most parrots are social birds that live in groups called flocks. African grey parrots live in flocks with as many as 20 to 30 birds.
           Many species are monogamous and spend their lives with only one mate. The mates work together to raise their young. Parrots
           throughout the flock communicate with one another by squawking and moving their tail feathers. Some parrots, like the kakapo, are nocturnal.
           They sleep during the day and search for food at night.<br>
           Diet<br>
           Parrots are omnivores, which means that they can eat both meat and vegetation. Most parrots eat a diet that contains nuts, flowers, fruit,
           buds, seeds and insects. Seeds are their favorite food. They have strong jaws that allow them to snap open nutshells to get to the seed that is inside. 
           Keas use their longer beaks to dig insects out of the ground for a meal, and kakapos chew on vegetation and drink the juices.</h3></div>
           </div>';
    }
}
$Parrot = new Parrot("Parrot","Colourful");
$Parrot->FactsParr();
