<?php
include 'animal.php';
class dog extends Animal{

    public function facts(){
    print 'The dog (Canis familiaris when considered a distinct species or Canis lupus familiaris when considered a subspecies of the wolf)
    is a member of the genus Canis (canines), which forms part of the wolf-like canids,and is the most widely abundant terrestrial carnivore.
    The dog and the extant gray wolf are sister taxa as modern wolves are not closely related to the wolves that were first domesticated,
     which implies that the direct ancestor of the dog is extinct.';
    }
}
$dog = new dog("dog","grey");
$dog->facts();
?>

