<!DOCTYPE html>
<html>
<head>
    <title>The Hamster</title>
    <style>
        body{
            background-image: linear-gradient(to right, #89f7fe , #66a6ff);
            background-size: cover;
        }
        .hamster{
            background-color:darkturquoise;
            width:50%;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body></body>
</html>
<?php
include 'animal.php';

class hamster extends animal{
    public function FactH(){
        print '<div class = hamster><h3>Hamsters may be small, but these friendly “pocket pets” sure have big hearts. The cuddly, 
               furry critters are one of the most popular small animal pets. Here are just a few of the many interesting facts about hamsters and their habits.
               <br>
               <b>1. Hamsters were “discovered” in the Syrian Desert less than 100 years ago.</b>
               Although hamsters are native to various parts of the world, Syrian hamsters are the most popular pet hamsters.
               Also referred to as golden hamsters and teddy bear hamsters, these fuzzy fellows grow to about six inches long
               and live, on average, two to three years.
               <br>
               <b>2. Hamsters are nocturnal creatures.</b>
                Because they sleep all day, hamsters can be very noisy at night. It is best to keep them out of your bedroom if you don’t want them disturbing
                you while you sleep. They can run on wheels in their cages all night long. During the day, they should ideally be kept in a quiet, dim area and
                left undisturbed to burrow and sleep in their cage bedding.</h3></div>';
    }
}
$Hamster = new hamster("Hamster","Orange");
$Hamster->FactH();
