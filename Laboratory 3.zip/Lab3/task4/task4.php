<!DOCTYPE html>
<html>
<head>
    <title>Zoo shop</title>
    <style>
        .wrapper {
            margin-left:auto;
            padding: 0;
            display: grid;
            grid-template-columns: 300px 300px 300px;
            grid-gap: 10px;
            background-color: #fff;
            color: #444;
        }

        .box {
            display: flex;
            flex-direction:column;
            background-color: #444;
            color: #fff;
            border-radius: 5px;
            padding: 20px;
            font-size: 150%;
        }
        div.img{
            text-align: center;
            padding-left: 5px;
            padding-right: 5px;
        }
        a{
            color:white;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <div class="box"><img src ="1.jpg" alt ="dog" width= 100% height="85%"><a href = "dog.php">Dog</a></div>
    <div class="box"><img src ="images.jpg" alt ="cat" width="100%" height="88%"><a href = "cat.php">Cat</a></div>
    <div class="box"><img src ="2.jpg" alt ="cat" width="100%" height="90%"><a href = "Hamster.php">Hamster</a></div>
    <div class="box"><img src ="3.jpg" alt ="cat" width="100%" height="90%"><a href = "Parrot.php">Parrot</a></div>
    <div class="box"><img src ="4.jpg" alt ="cat" width="100%" height="85%"><a href = "Fish.php">Fish</a></div>
    <div class="box"><img src ="5.jpg" alt ="cat" width="100%" height="90%"><a href = "Rabbit.php">Rabbit</a></div>
</div>

</body>
</html>