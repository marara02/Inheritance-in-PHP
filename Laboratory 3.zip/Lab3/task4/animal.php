<html>
<head>
    <title></title>
    <style>
        h1{
            color:midnightblue;
            text-align: center;
        }
    </style>
</head>
</html>
<?php
class Animal
{
    public $type;
    public $color;

    public function __construct($type, $color)
    {
        $this->$type = $type;
        $this->$color = $color;
        echo '<h1>Facts to Zoo animals.</h1>';
        echo '<br>';
        echo 'Color:'.$color;
        echo '<br>';
        echo 'Type:'.$type;
        echo '<br>';
    }

    public function __destruct()
    {
        echo '<h1>Enjoy with our Zoo</h1>';
        echo '<br>';
    }
}
?>

