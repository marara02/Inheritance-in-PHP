<!DOCTYPE html>
<html>
<head>
    <style>
        form {
            margin: 0 auto;
            width: 250px;
        }
        p{
            text-align: center;
            font-size: 40px;
        }
    </style>
</head>
<body>
<form action="first.php" method="post">
    Name: <input type="text" name="name"><br>
    Surname: <input type ="text" name ="surname"><br>
    E-mail: <input type="text" name="email"><br>
    Number: <input type = "number" name ="number"><br>
    Traffic: <input type = "number" name = "traffic"><br>
    <input type="submit" name = "submit">
</form></body>
<!--<form method="post" action="www.php">
    <input type="text" name="name" placeholder="Name"><br><br>
    <input type="text" name="surname" placeholder="Surname"><br><br>
    <input type="text" name="email" placeholder="Email"><br><br>
    <input type="number" name="number" placeholder="Number"><br><br>
    <form method = 'post'>
    <select name = 'traffics[]' >
        <option value = '30 Mb/s'>30 Mb/s</option>
        <option value = '60Mb/s'>60 Mb/s</option>
        <option value = '90 Mb/s'>90 Mb/s</option>
    </select><br></form>
    <input type="submit" name ="submit" value="Submit">
</form>
</body>
</html>
