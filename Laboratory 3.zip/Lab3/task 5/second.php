<?php
include 'firstt.php';

class second extends firstt
{
    public function choose()
    {
        if ($_POST["traffic"] == 60) {
            print '<p><img src = "11.png" alt = "internet" width ="25%" height ="30%"</p>';
            print '<p><img src = "tv.png" alt = "TV" width ="25%" height ="30%"</p>';
            print '<p>By choosing 60Mb/s , package include Internet and TV</p>';
    }

    }
}
$ss = new second();
$ss->choose();