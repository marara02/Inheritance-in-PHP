<?php
include 'first.php';
class firstVariant extends main{
    public function info(){
        print '<p><img src = "11.png" alt = "internet" width ="35%" height ="40%"</p>';
        print '<p>By choosing 30Mb/s , package include Internet</p>';
    }
}
$ff = new firstVariant("30Mb/s");
$ff->check();
$ff->info();