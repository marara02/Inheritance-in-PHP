<!DOCTYPE html>
<html>
<html>
<head>
    <meta charset="utf-8">
    <title>Tarif</title>
    <style>
        body{
            background-image: linear-gradient(to right, #48c6ef , #6f86d6);
            background-size: cover;
        }
        #main{
            text-align: center;
            color:indigo;
        }
        .all{
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .first{
            display: block;
            background-color: aqua;
            margin-right:5px;
            width:20%;
            text-align:center;
        }
        .second{
            display:block;
            background-color:lightseagreen;
            margin-right:5px;
            width:20%;
            text-align:center;
        }
        .third{
            display:block;
            background-color: aqua;
            width:20%;
            text-align: center;
        }
        a{
            text-decoration: none;
        }
    </style>
</head>
<body>
<h1 id = "main">Traffic schedule</h1>
<div class = "all">
    <div class = "first">
        <h2>30Mb/s</h2>
        <p>You will get internet</p>
        <img src = "11.png" alt ="internet" width = "35%" height="30%">
        <br>
        <p><a href ="firstV.php">Click here</a></p>
    </div>
    <div class = "second">
        <h2>60Mb/s</h2>
        <p>You will get Internet and TV</p>
        <img src = "11.png" alt ="internet" width = "35%" height="30%">
        <img src = "tv.png" alt ="internet" width = "35%" height="30%">
        <br>
        <p><a href ="second.php">Click here</a></p>
    </div>
    <div class ="third">
        <h2>90Mb/s</h2>
        <p>You will get Internet, TV and smartbox</p>
        <img src = "11.png" alt ="internet" width = "35%" height="30%">
        <img src = "tv.png" alt ="internet" width = "30%" height="30%">
        <img src = "ss.png" alt ="internet" width = "27%" height="20%">
        <br>
        <p><a href ="third.php">Click here</a></p>
    </div>
</div>
</body>
</html>