<?php
include 'firstt.php';

class third extends firstt
{
    public function choose2(){
        if ($_POST["traffic"] == 90) {
            print '<p><img src = "11.png" alt = "internet" width ="20%" height ="20%"</p>';
            print '<p><img src = "tv.png" alt = "TV" width ="20%" height ="20%"</p>';
            print '<p><img src = "ss.png" alt = "Smartbox" width ="20%" height ="20%"</p>';
            print '<p>By choosing 90Mb/s , package include Internet,TV and SmartBox</p>';
        }
    }
}
$tt = new third();
$tt->choose2();