<!DOCTYPE html>
<html>
<head>
    <style>
        body{
            background-image: linear-gradient(to right, #eecda3 , #ef629f);
            background-size: cover;
        }
        form {
            margin: 0 auto;
            width: 250px;
        }
        input[type=text]:hover{
            background-color: #eecda3;
        }
        p{
            text-align: center;
            font-size: 40px;
        }
    </style>
</head>
<body>
<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
    Name:<br> <input type="text" name="name"><br><br>
    Surname:<br> <input type ="text" name ="surname"><br><br>
    E-mail:<br> <input type="text" name="email"><br><br>
    Number:<br> <input type = "number" name ="number"><br><br>
    Traffic:<br> <input type = "number" name = "traffic"><br>
    <input type="submit" name = "submit">
</form></body>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo 'Welcome' . ' ' . $_POST["name"];
    echo '<br>';
    echo 'Your Surname:'.' '.$_POST["surname"];
    echo '<br>';
    echo 'Your email address is:' . $_POST["email"];
    echo '<br>';
    echo 'Your number:'.' '.$_POST["number"];
    echo '<br>';
    echo 'Traffic:';
    echo $_POST["traffic"];
}
class firstt
{
    public function __construct()
    {
        print '<p>Choose and register</p>';
    }

    public function __destruct()
    {
        // TODO: Implement __destruct() method.
        print '<p>Thank you</p>';
    }
}
//7$ff = new firstt("");