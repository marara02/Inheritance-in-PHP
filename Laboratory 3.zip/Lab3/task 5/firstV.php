<?php
include 'firstt.php';

class firstV extends firstt
{
    public function info()
    {
        if ($_POST["traffic"] == 30) {
            print '<p><img src = "11.png" alt = "internet" width ="35%" height ="40%"</p>';
            print '<p>By choosing 30Mb/s , package include Internet</p>';
        }
    }
}

$ff = new firstV();
$ff->info();