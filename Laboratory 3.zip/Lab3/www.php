<?php
include 'firstV.php';
echo 'Welcome'.' '.$_POST["name"];
echo '<br>';
echo $_POST["surname"];
echo '<br>';
echo 'Your email address is:'. $_POST["email"];
echo '<br>';
echo $_POST["number"]; ?>
